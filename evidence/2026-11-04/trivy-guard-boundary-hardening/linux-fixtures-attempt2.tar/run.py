import os,json,pathlib,platform,subprocess,shutil
root=pathlib.Path(__file__).resolve().parent
results={"platform":platform.platform(),"arch":platform.machine(),"uid":os.getuid(),"suites":[]}
relative=open('/proc/self/cgroup').read().strip().split(':')[-1];group=pathlib.Path('/sys/fs/cgroup')/relative.lstrip('/')
results['capabilityProbe']={'selfCgroup':relative,'selfCgroupWritable':os.access(group,os.W_OK),'killWritable':os.access(group/'cgroup.kill',os.W_OK),'bwrapAvailable':shutil.which('bwrap') is not None,'unshareAvailable':shutil.which('unshare') is not None,'cgroupCreated':False,'permissionsExpanded':False}
commands=[('guard-linux',['node','--test','--test-concurrency=1','infra/observability/testing/scanner-validation-guard.test.mjs','infra/observability/testing/scanner-validation-review.test.mjs','infra/observability/testing/scanner-validation-boundary.test.mjs'],'current'),('path-races-linux',['python3','-B','infra/observability/testing/scanner-validation-path-races.test.py'],'current'),('evidence-protection-linux',['python3','-B','infra/observability/testing/frozen-evidence-writes.test.py'],'current'),('legacy-guard-linux',['node','--test','--test-concurrency=1','infra/observability/testing/scanner-validation-guard.test.mjs','infra/observability/testing/scanner-validation-review.test.mjs'],'legacy')]
for name,command,tree in commands:
 p=subprocess.run(command,cwd=root/tree,capture_output=True,text=True,timeout=100)
 results['suites'].append({'name':name,'command':command,'exit':p.returncode,'log':p.stdout+p.stderr,'sourceTree':tree})
 if p.returncode:break
print(json.dumps(results))
