// Accidental-write protection for TRUSTED test replays, not an OS security sandbox.
// Loaded with --import before the unchanged tests. Historical files stay read-only
// to this Node API layer; all write destinations must be in its disposable tree.
import fs from 'node:fs';import fsp from 'node:fs/promises';import path from 'node:path';import {syncBuiltinESMExports} from 'node:module';
import {fileURLToPath} from 'node:url';
const requested=process.env.TRIVY_FROZEN_REPLAY_ROOT;
if(!requested)throw Error('FROZEN_REPLAY_PRIVATE_ROOT_REQUIRED');
const root=fs.realpathSync(requested),st=fs.statSync(root);
if(root!==fs.realpathSync(process.cwd())||st.uid!==process.getuid()||(st.mode&0o077)
 ||!fs.existsSync(path.join(root,'.frozen-replay.json')))throw Error('FROZEN_REPLAY_IDENTITY_REQUIRED');
const beneath=p=>{const r=path.relative(root,p);return !r||r!=='..'&&!r.startsWith('..'+path.sep)&&!path.isAbsolute(r);};
function check(value){
 if(typeof value==='number')throw Error('FROZEN_EVIDENCE_UNTRACKED_FD_WRITE_DENIED');
 if(value instanceof URL)value=fileURLToPath(value);
 const target=path.resolve(String(value));if(!beneath(target))throw Error('FROZEN_EVIDENCE_WRITE_OUTSIDE_REPLAY_DENIED');
 let current=target;while(!fs.existsSync(current)){const next=path.dirname(current);if(next===current)throw Error('FROZEN_REPLAY_PATH_UNKNOWN');current=next;}
 if(!beneath(fs.realpathSync(current)))throw Error('FROZEN_REPLAY_SYMLINK_ESCAPE_DENIED');
}
const writing=flags=>typeof flags==='number'?Boolean(flags&(fs.constants.O_WRONLY|fs.constants.O_RDWR|fs.constants.O_CREAT|fs.constants.O_TRUNC|fs.constants.O_APPEND)):flags!=='r'&&flags!=='rs';
for(const api of [fs,fsp]){
 for(const name of ['writeFile','appendFile','mkdir','mkdtemp','rm','rmdir','unlink','truncate','chmod','chown','utimes',
  'writeFileSync','appendFileSync','mkdirSync','mkdtempSync','rmSync','rmdirSync','unlinkSync','truncateSync','chmodSync','chownSync','utimesSync']){
  if(typeof api[name]!=='function')continue;const original=api[name];api[name]=function(value,...args){check(value);return original.call(this,value,...args);};
 }
 for(const name of ['rename','renameSync','copyFile','copyFileSync','cp','cpSync','link','linkSync']){
  if(typeof api[name]!=='function')continue;const original=api[name];api[name]=function(from,to,...args){if(name.startsWith('rename'))check(from);check(to);return original.call(this,from,to,...args);};
 }
 for(const name of ['symlink','symlinkSync']){
  if(typeof api[name]!=='function')continue;const original=api[name];api[name]=function(target,destination,...args){check(destination);return original.call(this,target,destination,...args);};
 }
 for(const name of ['open','openSync']){
  if(typeof api[name]!=='function')continue;const original=api[name];api[name]=function(value,flags,...args){if(writing(flags))check(value);return original.call(this,value,flags,...args);};
 }
}
const stream=fs.createWriteStream;fs.createWriteStream=function(value,...args){check(value);return stream.call(this,value,...args);};
syncBuiltinESMExports();
