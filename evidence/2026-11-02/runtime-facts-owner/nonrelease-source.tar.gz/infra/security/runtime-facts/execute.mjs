import fs from 'node:fs';
import {spawn} from 'node:child_process';
import {collectRuntimeFacts} from './collector.mjs';
import {executionPayload} from './projection.mjs';
import {sha,fail} from '../summary-v2/codec.mjs';

// Executes the ORIGINAL command, not an adapter or recreated scanner. The
// observer uses an inherited anonymous pipe; no decrypted content hits disk.
export async function captureStage({sourceId,command,binding,env=process.env,cwd=process.cwd(),onOutput=()=>{}}){
  if(sourceId==='sops'&&!env.ISOLATED_BOUNDARY_CONTEXT)fail('SOPS collection requires existing isolated executor boundary; production Secret access forbidden');
  const observer=new URL('./observe.mjs',import.meta.url).pathname;
  const child=spawn('/bin/sh',['-c',command],{cwd,env:{...env,RUNTIME_FACT_SOURCE:sourceId,
    NODE_OPTIONS:[env.NODE_OPTIONS,'--import='+observer].filter(Boolean).join(' ')},stdio:['ignore','pipe','pipe','pipe']});
  let stdout='',stderr='',raw='',overflow=false,errorClass=null;
  const limit=24*1024*1024;
  const add=(name,b)=>{if(Buffer.byteLength(stdout)+Buffer.byteLength(stderr)+Buffer.byteLength(raw)+b.length>limit){overflow=true;child.kill('SIGTERM');return;}
    if(name==='raw')raw+=b;else{if(name==='stdout')stdout+=b;else stderr+=b;onOutput(name,b);}};
  child.stdout.on('data',b=>add('stdout',b));child.stderr.on('data',b=>add('stderr',b));child.stdio[3].on('data',b=>add('raw',b));
  child.on('error',e=>{errorClass=e.code??e.name;});
  const completion=await new Promise(resolve=>child.once('close',(code,signal)=>resolve({code,signal})));
  if(overflow)fail('runtime observation buffer exceeded; no truncated facts accepted');
  const packets=raw.trim()?raw.trim().split('\n').map(x=>JSON.parse(x)):[];
  // Current specialized source commands are one Node Gate each. Any accidental
  // duplicate observer is rejected rather than choosing a convenient packet.
  if(['sops','falco-baseline','falco-final'].includes(sourceId)&&packets.length!==1)fail('specialized source observation absent or duplicated');
  const observation=packets[0],payload=executionPayload({sourceId,command,exitStatus:completion.code,stdout,stderr,observation});
  const envelope=collectRuntimeFacts({sourceId,binding,execution:{command,exitStatus:completion.code,signal:completion.signal,errorClass},payload,
    evidence:[{kind:'ACTUAL_PROCESS_EXECUTION',stdoutSha256:sha(stdout),stderrSha256:sha(stderr),observerPackets:packets.length,
      events:observation?.events??[],sourcePayloadClass:observation?'PASSIVE_IN_MEMORY_ORIGINAL_GATE_OBSERVATIONS':'ORIGINAL_COMMAND_EXIT_OBSERVATIONS'}]});
  return {envelope,exitStatus:completion.code,signal:completion.signal,stdout,stderr};
}
